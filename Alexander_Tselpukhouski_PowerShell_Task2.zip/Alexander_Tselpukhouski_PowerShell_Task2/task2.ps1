Function GenerateAccountsNew {
param(
[parameter(Mandatory=$true)][String]$path_to_source_file, 
[parameter(Mandatory=$true)][String]$accounts_filename
)

$accounts_filename_path = "$path_to_source_file" + "\" + "$accounts_filename"

$accounts_new_path = $path_to_source_file + "\" + "accounts_new.csv"


$accounts = Import-Csv -Path $accounts_filename_path
$TextInfo = (Get-Culture).TextInfo



New-Item -Path $accounts_new_path
echo "id,location_id,name,title,email,department" >> $accounts_new_path

for($i=0; $i -le ($accounts.Count -1); $i++) {

$new_name = $TextInfo.ToTitleCase($accounts[$i].name)
$new_id = $accounts[$i].id
$new_location_id = $accounts[$i].location_id
$new_title = $accounts[$i].title
$email_name = $new_name.ToLower() -replace "^\w*\s"
$email_surname = $new_name.ToLower().Substring(0,1)
$new_email = $email_surname + $email_name + "@abc.com"
$new_departament = $accounts[$i].department


$repeat_email = $email_surname + $email_name + $new_location_id + "@abc.com"

#checking email count in a file
$checkrepeat = Get-Content -Path .\accounts_new.csv | Select-String $new_email
$Crepeat = $checkrepeat.Count

#choose what email to use if repeat(> 1) or not
if ( $Crepeat -gt 0 ) {
"$new_id," + "$new_location_id," + "$new_name," + '"' + "$new_title" + '",' + "$repeat_email," + "$new_departament" >> $accounts_new_path
}
else
{
"$new_id," + "$new_location_id," + "$new_name," + '"' + "$new_title" + '",' + "$new_email," + "$new_departament" >> $accounts_new_path
}

}

}

GenerateAccountsNew
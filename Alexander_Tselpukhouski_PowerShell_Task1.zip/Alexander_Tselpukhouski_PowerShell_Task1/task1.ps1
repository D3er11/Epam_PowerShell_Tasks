Function CIDRToNetMask {
  [CmdletBinding()]
  Param(
    [ValidateRange(0,32)]
    [int16]$PrefixLength=0
  )
#multiply CIDR by 1, fill empty spaces with 0
  $bitString=('1' * $PrefixLength).PadRight(32,'0')

  $strBuilder=New-Object -TypeName Text.StringBuilder

#convert bit value to mask, append (.) after 8 bits  
  for($i=0;$i -lt 32;$i+=8){
    $8bitString=$bitString.Substring($i,8)
    [void]$strBuilder.Append("$([Convert]::ToInt32($8bitString,2)).")
  }
#remove last (.)
  $strBuilder.ToString().TrimEnd('.')
}

Function CheckIfSameNetwork {
param (
[parameter(Mandatory=$true)][Net.IPAddress]$ip1,

[parameter(Mandatory=$true)][Net.IPAddress]$ip2,

[parameter(Mandatory=$true)][String]$mask
)

try { 
	$mask_int = [int16]$mask
	$mask1 = CIDRToNetMask $mask_int
	$mask1 = [IPAddress]$mask1
	$mask1
}
catch {
	"Mask is already IPAddress"
	$mask1 = [IPAddress]$mask
	$mask1
}

if (
($ip1.address -band $mask1.address) -eq ($ip2.address -band $mask1.address)
) {
	$true
}
else {
	$false
}

}

echo "Executing script for: 192.168.1.1 192.168.1.55 24"
CheckIfSameNetwork 192.168.1.1 192.168.1.55 24

echo "Executing script for: 192.168.1.1 192.168.1.55 255.255.255.0"
CheckIfSameNetwork 192.168.1.1 192.168.1.55 255.255.255.0

echo "Executing script for: 192.168.1.1 192.168.22.55 24"
CheckIfSameNetwork 192.168.1.1 192.168.22.55 24

echo "Executing script for: 192.168.1.1 192.168.22.55 255.255.255.0"
CheckIfSameNetwork 192.168.1.1 192.168.22.55 255.255.255.0